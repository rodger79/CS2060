Name:				Rodger Byrd
Program Name:		Homework 5 Read and Reverse II
Purpose:			format text files
Manually Compile:	$ gcc --std=c99 -Wall -o ReadARevIIByrd ReadARevIIRodgerByrd.c && ./ReadARevIIByrd  -L < input.txt
Problems:			probably could have done a cleaner version of the word reverse by optimizing count
Testing Proc:		test multiple input files
Assign Improvennts:	NA
