Name:				Rodger Byrd
Program Name:		Homework  BlackJack II Structures
Purpose:			Play BlackJack
Manually Compile:	gcc --std=c99 -Wall -o bjStructureByrd bjstructureByrd.c && ./bjStructureByrd 
Problems:			Not too many, some debugging for logic function
Testing Proc:		play the game
Assign Improvennts:	NA
