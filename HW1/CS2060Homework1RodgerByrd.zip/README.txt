Name:				Rodger Byrd
Program Name:		Homework 1 Compiler Check
Purpose:			Make sure compiler is working
Manually Compile:	gcc --std=c99 -Wall -o HW1RodgerByrd.exe CompilerCheckHelloWorld.c
Problems:			64bit version of cygwin didn't work, so used 32 bit
Testing Proc:		NA
Assign Improvennts:	Too easy perhaps
