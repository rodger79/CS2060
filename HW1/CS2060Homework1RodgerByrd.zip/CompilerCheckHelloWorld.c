//Filename:			CompilerCheckHelloWorld.c
//Student Name:		Rodger Byrd
//Date:				8-28-15
//Purpose:			make sure compiler works
//How to use:		execute the output to get the message

#include <stdio.h>

//Function: main
//Prototype with arg Types: No Arguments
//HOw to use: Runs automatically
//What it does: Says Hello

int main(){
		printf("Hello World!, I am here.\n");
		return 0;
}