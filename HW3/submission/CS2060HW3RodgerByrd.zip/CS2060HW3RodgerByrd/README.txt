Name:				Rodger Byrd
Program Name:		Homework 3 Read and Reverse 
Purpose:			Play BlackJack
Manually Compile:	$ gcc --std=c99 -Wall -o test HW3RodgerByrd.c && ./hw3rbyrdoutput -W <wTestMaster.txt
Problems:			probably could have done a cleaner version of the word reverse by optimizing count
Testing Proc:		test multiple input files
Assign Improvennts:	NA
