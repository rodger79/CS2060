Name:				Rodger Byrd
Program Name:		Homework 2 BlackJack
Purpose:			Play BlackJack
Manually Compile:	$ gcc --std=c99 -Wall -o HW2RodgerByrd.exe blackjack.c
Problems:			Not too many, some debugging for logic function
Testing Proc:		play the game
Assign Improvennts:	NA
